package einzelhandel.handelsapp;

/**
* @author Steven Tellekamp, Justus Hardtke, Maik Hämpke, Sebastian Naczk, Waqas Daud, Katharina Müller
* @version 1.0 08.11.2019
*
*/
public class HandelsApp2 {

  public static void main(String [] args){
    new HandelsController().run();
  }
}